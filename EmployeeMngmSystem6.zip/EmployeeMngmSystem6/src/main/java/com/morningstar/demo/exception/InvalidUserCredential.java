package com.morningstar.demo.exception;

public class InvalidUserCredential extends RuntimeException {

	public InvalidUserCredential(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	public InvalidUserCredential() {
		
		// TODO Auto-generated constructor stub
	}
	
}
