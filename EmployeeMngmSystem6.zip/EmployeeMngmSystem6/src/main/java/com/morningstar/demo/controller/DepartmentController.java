package com.morningstar.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.morningstar.demo.entity.Department;
import com.morningstar.demo.service.DepartmentService;

@RestController
public class DepartmentController {

	@Autowired
	DepartmentService departmentService;
	
	// Add Department
	@PostMapping("/Dept")
	public ResponseEntity<String> add(@RequestBody Department department) {
		String status=departmentService.addDepartment(department);	
		return new ResponseEntity<String>(status,HttpStatus.OK); 
	}
	
	// Get Department List
	@GetMapping("/DeptList")
	public ResponseEntity<List<Department>> deptList()
	{
		
		List<Department>dept=departmentService.deptList();
		return new ResponseEntity<List<Department>>(dept,HttpStatus.OK);
	}
	
	
}
