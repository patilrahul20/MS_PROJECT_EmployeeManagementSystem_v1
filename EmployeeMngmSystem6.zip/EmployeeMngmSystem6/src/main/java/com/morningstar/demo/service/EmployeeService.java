package com.morningstar.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.morningstar.demo.dto.EmployeeDto;
import com.morningstar.demo.dto.EmployeeLoginDto;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.exception.EmployeeNotFound;

@Service
public interface EmployeeService {

	public List<Employee> getEmployee();

	public String addEmployee(EmployeeDto newEmployee);

	public String deleteEmployee(int id) throws EmployeeNotFound;

	public Employee getEmployeebyId(int id) throws EmployeeNotFound;

	public void updateEmployee(Employee emp, int id)  throws EmployeeNotFound;

	public String login(EmployeeLoginDto employee);

	
}
