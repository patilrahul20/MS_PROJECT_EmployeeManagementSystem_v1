package com.morningstar.demo.exception;


public class EmployeeNotFound extends RuntimeException {

	public EmployeeNotFound(String msg) {
		super(msg);
	}

	public EmployeeNotFound() {
		// TODO Auto-generated constructor stub
	}
}
