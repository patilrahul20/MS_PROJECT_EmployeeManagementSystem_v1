package com.morningstar.demo.service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.morningstar.demo.dto.EmployeeDto;
import com.morningstar.demo.dto.EmployeeLoginDto;
import com.morningstar.demo.entity.Department;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.exception.EmployeeNotFound;
import com.morningstar.demo.exception.InvalidUserCredential;
import com.morningstar.demo.repository.DepartmentRepository;
import com.morningstar.demo.repository.EmployeeRepository;



@Service
public class EmployeeServiceImpl implements EmployeeService {
	//Logger
	// static Logger log = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	@Autowired
   EmployeeRepository employeeRepository;

	
	@Autowired
	DepartmentRepository departmentRepository;
	
	@Override
	public List<Employee> getEmployee() {	
		return employeeRepository.findAll();
	}

	@Override
	public String addEmployee(EmployeeDto employee) {
		Employee emp=new Employee();
		emp.setEmpFname(employee.getEmpFname());
		emp.setEmpLname(employee.getEmpLname());
		emp.setEmpAge(employee.getEmpAge());
		emp.setEmpRole(employee.getEmpRole());
		emp.setEmpSalary(employee.getEmpSalary());
		emp.setEmail(employee.getEmail());
		emp.setPassword(employee.getPassword());
		
		
		Department d=departmentRepository.findById(employee.getDepartment()).get();
		emp.setDepartment(d);
		employeeRepository.save(emp);
		return "Employee Added Successfully. ";
	}
	

	@Override
	public String deleteEmployee(int id) throws EmployeeNotFound {
		 Optional<Employee> emp=employeeRepository.findById(id);
		if(emp.isPresent())
		{
			employeeRepository.deleteById(id);
			return "Employee Delete Successfully. "; 
		}
		
		else {
			throw new EmployeeNotFound();
		}
	}

	@Override
	public Employee getEmployeebyId(int id) throws EmployeeNotFound {
	
		Employee emp;
		if(employeeRepository.findById(id).isEmpty())
		{
			throw new EmployeeNotFound();
		}else
		{
			emp=employeeRepository.findById(id).get();
		}
		return emp;
		 
	}

	@Override
	public void updateEmployee(Employee emp, int id) throws EmployeeNotFound {
		String empFname=emp.getEmpFname();
		String empLname=emp.getEmpLname();
		String empRole=emp.getEmpRole();
		int empAge=emp.getEmpAge();
		double empSalary=emp.getEmpSalary();
		Department dept=emp.getDepartment();
		String email=emp.getEmail();
		String password=emp.getPassword();
		
		Optional<Employee> e=employeeRepository.findById(id);
		Employee empUpdate;
		if(e.isPresent())
		{
			empUpdate=e.get();
			if(empFname !=null)
			{
				empUpdate.setEmpFname(empFname);
			}
			if(empLname !=null)
			{
				empUpdate.setEmpLname(empLname);
			}
			if(empRole !=null)
			{
				empUpdate.setEmpRole(empRole);
			}
			if(empAge !=0)
			{
				empUpdate.setEmpAge(empAge);
			}
			if(empSalary !=0.0)
			{
				empUpdate.setEmpSalary(empSalary);
			}
			if(dept !=null)
			{
				empUpdate.setDepartment(dept);
			}
			if(email !=null)
			{
				empUpdate.setEmail(email);;
			}
			if(password !=null)
			{
				empUpdate.setPassword(password);
			}
			 employeeRepository.save(empUpdate);
		}
		else
			throw new EmployeeNotFound("Employee Not Found");
	}

	@Override
	public String login(EmployeeLoginDto employee) throws InvalidUserCredential{
		String email=employee.getEmail();
		String password=employee.getPassword();
		
		Employee emp=employeeRepository.findEmp(email, password);
		if(emp != null)
		{
			System.out.println("FirstName :: "+emp.getEmpFname() +"\n"+"LastName ::"+emp.getEmpLname()+"\n"+"Role ::"+emp.getEmpRole()+"\n"+"Age ::"+emp.getEmpAge());
//		   log.info("-----User Log in-----");
//		   log.info("User Name :: "+emp.getEmail());
			return "Successfully Login ...!!!!!! ";
		}
		else
		throw new InvalidUserCredential();
	}
}
