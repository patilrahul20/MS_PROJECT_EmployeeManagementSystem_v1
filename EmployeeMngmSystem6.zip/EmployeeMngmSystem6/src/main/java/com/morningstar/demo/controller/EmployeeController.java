package com.morningstar.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.morningstar.demo.dto.EmployeeDto;
import com.morningstar.demo.dto.EmployeeLoginDto;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.exception.EmployeeNotFound;
import com.morningstar.demo.exception.InvalidUserCredential;
import com.morningstar.demo.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/project/v4")
public class EmployeeController {
	//Logger
	private static Logger log = LoggerFactory.getLogger(EmployeeController.class);
	@Autowired
	EmployeeService employeeService;
	
	// Get Employee List
	@GetMapping("/Employees")
	public ResponseEntity<List<Employee>> getEmployee()
	{
		log.info("ALL Employees Fetch");
		List<Employee>list=employeeService.getEmployee();
		return new ResponseEntity<List<Employee>>(list,HttpStatus.OK);
	}
	
	// Add Employee 
	@PostMapping("/Employee")
	public ResponseEntity<String> add(@Valid @RequestBody EmployeeDto newEmployee) {
        log.info("Employee Added");
		String status=employeeService.addEmployee(newEmployee);	
		return new ResponseEntity<String>(status,HttpStatus.OK);   
	}
	
	// Delete Employee By ID
	@DeleteMapping("/Employee/{id}")
	public ResponseEntity<String>  delete( @PathVariable("id") int id) throws EmployeeNotFound{

		log.info("Employee Deleted");
		return new ResponseEntity<String>(employeeService.deleteEmployee(id),HttpStatus.OK);
	}
	
	//Get Employee By Id
	@GetMapping("/Employee/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") int id) throws EmployeeNotFound
	{
		//Employee emp=employeeService.getEmployeebyId(id);
		log.info("Employee Fetch by ID "+id);
		return new ResponseEntity<Employee>(employeeService.getEmployeebyId(id),HttpStatus.OK);
	}
	
	//Update Employee
	@PutMapping("/Employee/{id}")
	public ResponseEntity<String> updateEmployee(Employee emp, @PathVariable ("id") int id)
	{ 
		log.info("Update Employee Details by ID "+id);
		String status="";
		try {
		 employeeService.updateEmployee(emp,id);
		}catch(EmployeeNotFound ex) {
			status=ex.getMessage();
			return new ResponseEntity<String>(status,HttpStatus.BAD_REQUEST);
		}
		status= "Employee Update Successfully";
		 return new ResponseEntity<String>(status,HttpStatus.OK);
	}	
	
	//login
	@PostMapping("/login")
	public ResponseEntity<String> login(@Valid @RequestBody EmployeeLoginDto employee)throws InvalidUserCredential {
		   log.info("-----User Log in-----");
		   log.info("User Name :: "+employee.getEmail());
		return new ResponseEntity<String>(employeeService.login(employee),HttpStatus.OK);
	}
	 
	//---
	   @ResponseStatus(HttpStatus.BAD_REQUEST)
	   @ExceptionHandler(MethodArgumentNotValidException.class)
	   public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) 
	   {
	       Map<String, String> errors = new HashMap<>();

	       ex.getBindingResult().getFieldErrors().forEach(error ->
	               errors.put(error.getField(), error.getDefaultMessage()));
	       return errors;
	   }
}
