package com.morningstar.demo.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Employee_Table")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@Column(name="EMP_ID")
	private int empid;
	
	@Column(name="EMP_FNAME")
	private String empFname;
	
	@Column(name="EMP_LNAME")
	private String empLname;
	
	@Column(name="EMP_AGE")
	private int empAge;
	
	@Column(name="EMP_ROLE")
	private String empRole;
	
	@Column(name="EMP_SALARY")
	private double empSalary;
	
	@Column(name="EMP_EMAIL")
	private String email;
	
	
	public Employee() {
		super();
	}
	public Employee(int empid, String empFname, String empLname, int empAge, String empRole, double empSalary,
			String email, String password, Department department) {
		this.empid = empid;
		this.empFname = empFname;
		this.empLname = empLname;
		this.empAge = empAge;
		this.empRole = empRole;
		this.empSalary = empSalary;
		this.email = email;
		this.password = password;
		this.department = department;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Column(name="EMP_PASSWORD")
	private String password;
	
	@ManyToOne (cascade = CascadeType.PERSIST)
    private Department department;	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpFname() {
		return empFname;
	}
	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}
	public String getEmpLname() {
		return empLname;
	}
	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	public String getEmpRole() {
		return empRole;
	}
	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	
}
