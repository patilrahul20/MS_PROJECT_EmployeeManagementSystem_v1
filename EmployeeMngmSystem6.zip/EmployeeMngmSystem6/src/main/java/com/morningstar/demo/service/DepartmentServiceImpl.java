package com.morningstar.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.morningstar.demo.entity.Department;
import com.morningstar.demo.repository.DepartmentRepository;
import com.morningstar.demo.repository.EmployeeRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository departmentRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public String addDepartment(Department department) {
		
		departmentRepository.save(department);
		return "Department Added";
	}

	@Override
	public List<Department>  deptList() {	
		return departmentRepository.findAll();
	}

	
	

}
