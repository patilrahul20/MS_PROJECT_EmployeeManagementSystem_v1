package com.morningstar.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.morningstar.demo.entity.Employee;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	

	@Query(value ="SELECT * from employee_table em where em.emp_email = ?1 and em.emp_password = ?2",nativeQuery = true)
	Employee findEmp(String email,String password);
	
}
