package com.morningstar.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.morningstar.demo.entity.Department;

@Service
public interface DepartmentService {
	
	public String addDepartment(Department department) ;
	
	public List<Department>  deptList();

	
}
