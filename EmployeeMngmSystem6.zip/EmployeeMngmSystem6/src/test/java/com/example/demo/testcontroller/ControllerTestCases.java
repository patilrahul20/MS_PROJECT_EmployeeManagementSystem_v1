package com.example.demo.testcontroller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.morningstar.demo.controller.EmployeeController;
import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.service.EmployeeServiceImpl;

@SpringBootTest(classes =ControllerTestCases.class )
class ControllerTestCases {

	@Mock
	EmployeeServiceImpl employeeServiceImpl;
	
	@InjectMocks
	EmployeeController employeeController;
	
	public List<Employee>emp;
	@Test
	@Order(1)
	public void test_getEmployee() {
		emp=new ArrayList<>();
		emp.add(new Employee(1,"Rahul","Patil",25,"Associate",50000,"rahul@gmail.com","rahul20",null));
		emp.add(new Employee(2,"Prathmesh","Shinde",24,"Associate",50000,"shinde@gmail.com","shinde18",null));
		
		when(employeeServiceImpl.getEmployee()).thenReturn(emp);
		
		ResponseEntity<List<Employee>> result=employeeController.getEmployee();
		 
		Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
		Assertions.assertEquals(2,result.getBody().size());
	
	}

}
