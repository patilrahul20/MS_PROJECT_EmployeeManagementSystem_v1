package com.example.demo.testservice;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.morningstar.demo.entity.Employee;
import com.morningstar.demo.repository.EmployeeRepository;

import com.morningstar.demo.service.EmployeeServiceImpl;

@SpringBootTest(classes = {ServiceTestCases.class})
class ServiceTestCases {

	@Mock
	EmployeeRepository employeeRepository;
	
	@InjectMocks
	EmployeeServiceImpl employeeServiceImpl;
	
	public List<Employee>emp;
	
	@Test
	@Order(1)
	public void test_getAllEmp() {
		emp=new ArrayList<>();
		emp.add(new Employee(1,"Rahul","Patil",25,"Associate",50000,"rahul@gmail.com","rahul20",null));
		emp.add(new Employee(2,"Prathmesh","Shinde",24,"Associate",50000,"shinde@gmail.com","shinde18",null));
		
		when(employeeRepository.findAll()).thenReturn(emp);
		
		Assertions.assertEquals(2, employeeServiceImpl.getEmployee().size());
		Assertions.assertEquals(true, employeeServiceImpl.getEmployee().contains(emp.get(1)));
	}

}
